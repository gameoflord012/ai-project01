var searchData=
[
  ['mapcoordstopixel_0',['mapCoordsToPixel',['../classsf_1_1RenderTarget.html#ad92a9f0283aa5f3f67e473c1105b68cf',1,'sf::RenderTarget::mapCoordsToPixel(const Vector2f &amp;point) const'],['../classsf_1_1RenderTarget.html#a848eee44b72ac3f16fa9182df26e83bc',1,'sf::RenderTarget::mapCoordsToPixel(const Vector2f &amp;point, const View &amp;view) const']]],
  ['mappixeltocoords_1',['mapPixelToCoords',['../classsf_1_1RenderTarget.html#a0103ebebafa43a97e6e6414f8560d5e3',1,'sf::RenderTarget::mapPixelToCoords(const Vector2i &amp;point) const'],['../classsf_1_1RenderTarget.html#a2d3e9d7c4a1f5ea7e52b06f53e3011f9',1,'sf::RenderTarget::mapPixelToCoords(const Vector2i &amp;point, const View &amp;view) const']]],
  ['memoryinputstream_2',['MemoryInputStream',['../classsf_1_1MemoryInputStream.html#a2d78851a69a8956a79872be41bcdfe0e',1,'sf::MemoryInputStream']]],
  ['microseconds_3',['microseconds',['../classsf_1_1Time.html#a8a6ae28a1962198a69b92355649c6aa0',1,'sf::Time']]],
  ['milliseconds_4',['milliseconds',['../classsf_1_1Time.html#a9231f886d925a24d181c8dcfa6448d87',1,'sf::Time']]],
  ['move_5',['move',['../classsf_1_1Transformable.html#a86b461d6a941ad390c2ad8b6a4a20391',1,'sf::Transformable::move(float offsetX, float offsetY)'],['../classsf_1_1Transformable.html#ab9ca691522f6ddc1a40406849b87c469',1,'sf::Transformable::move(const Vector2f &amp;offset)'],['../classsf_1_1View.html#a0c82144b837caf812f7cb25a43d80c41',1,'sf::View::move(float offsetX, float offsetY)'],['../classsf_1_1View.html#a4c98a6e04fed756dfaff8f629de50862',1,'sf::View::move(const Vector2f &amp;offset)']]],
  ['music_6',['Music',['../classsf_1_1Music.html#a0bc787d8e022b3a9b89cf2c28befd42e',1,'sf::Music']]],
  ['mutex_7',['Mutex',['../classsf_1_1Mutex.html#a9bd52a48320fd7b6db8a78037aad276e',1,'sf::Mutex']]]
];
